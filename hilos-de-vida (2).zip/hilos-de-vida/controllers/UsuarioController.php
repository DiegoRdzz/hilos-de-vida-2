<?php 
require_once  $_SERVER['DOCUMENT_ROOT'] . "/config/DataBase.php";
require_once  $_SERVER['DOCUMENT_ROOT'] . "/models/Usuario.php"; 

?>